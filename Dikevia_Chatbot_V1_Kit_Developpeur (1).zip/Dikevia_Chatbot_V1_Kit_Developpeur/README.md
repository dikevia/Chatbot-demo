# Dikevia — Chatbot juridique V1 (démonstrateur mobile)

Assistant juridique pour la fonction publique territoriale : question → recherche dans le CGFP (index local) et sur Légifrance/PISTE → réponse sourcée, ou abstention.

**État honnête : voir `docs/08_ETAT_DU_PROJET.md`.** L'APK n'a PAS encore été généré ni testé sur un appareil Android ; le workflow qui le génère est fourni mais n'a jamais été exécuté.

## Architecture en une phrase
Une application web mobile (`frontend/`, installable en PWA) + un serveur FastAPI (`backend/dev_main.py`) qui détient toutes les clés (PISTE, IA). Capacitor emballe la même application web dans un APK. Aucune base de données.

## Où lire quoi
| Besoin | Document |
|---|---|
| Installer sur mon téléphone (sans PC) | `docs/07_DEPLOIEMENT_ET_APK.md` |
| Ce qui marche / n'est pas testé | `docs/08_ETAT_DU_PROJET.md` |
| Architecture et choix technique | `docs/06_ARCHITECTURE.md` |
| Connecteur Légifrance/PISTE | `docs/09_CONNECTEUR_PISTE.md` |
| Moteur juridique, PostgreSQL reporté, feuille de route | `docs/10_MOTEUR_PGSQL_ET_FEUILLE_DE_ROUTE.md` |

## Lancement local (développeur)
```bash
python -m venv .venv && source .venv/bin/activate
pip install -r backend/requirements-dev.txt
cp .env.example .env      # renseigner PISTE / IA si disponibles (jamais committer .env)
PYTHONPATH=backend uvicorn dev_main:app --app-dir backend --reload
```
Ouvrir http://127.0.0.1:8000 (Chrome Android : menu ⋮ → « Installer l'application »).

## Tests
```bash
(cd backend && PYTHONPATH=. python -m unittest tests.test_cgfp_campaign tests.test_guard tests.test_article_ref_and_piste_validation)
node --test tests/frontend/chat-logic.test.js
PYTHONPATH=backend pytest -q backend/tests   # suite complète, nécessite les dépendances
```
