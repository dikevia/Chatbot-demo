Montage « un seul fichier » pour un dépôt GitHub créé depuis un téléphone.
À la racine du dépôt : le .zip du kit + `Dockerfile` (copie de Dockerfile.racine) + `.github/workflows/android-apk.yml` (copie de android-apk.racine.yml).
Voir docs/07_DEPLOIEMENT_ET_APK.md, étape 0. Non testé sur GitHub/Render : seule la décompression a été simulée.
