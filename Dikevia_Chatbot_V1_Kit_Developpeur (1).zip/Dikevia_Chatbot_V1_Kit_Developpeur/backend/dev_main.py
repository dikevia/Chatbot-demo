"""Point d'entrée local du chatbot V1 — sans PostgreSQL, sans persistance.

Démonstrateur technique : non destiné à la production ni à une exposition sur Internet
(aucune authentification, aucun quota par utilisateur).
"""
import logging
from pathlib import Path
from typing import Any

from fastapi import Depends, FastAPI, HTTPException, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.exceptions import RequestValidationError
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

from app.config import settings
from app.guard import RateLimiter, client_key, parse_origins, token_is_valid
from app.cgfp import search_cgfp
from app.legifrance import connector as legifrance
from app.orchestrator import LegalOrchestrator
from app.schemas import AskRequest

logger = logging.getLogger("dikevia.dev")
ROOT = Path(__file__).resolve().parents[1]
FRONTEND = ROOT / "frontend"

app = FastAPI(title="Dikevia Chatbot V1 — démonstrateur", version="1.0.0")
orchestrator = LegalOrchestrator()
limiter = RateLimiter(settings.dikevia_rate_limit_per_min, 60)

# L'application Android (Capacitor) et la PWA appellent ce serveur depuis une autre origine.
app.add_middleware(
    CORSMiddleware,
    allow_origins=parse_origins(settings.dikevia_allowed_origins),
    allow_methods=["GET", "POST"],
    allow_headers=["Content-Type", "X-Demo-Token"],
    max_age=600,
)


async def require_access(request: Request):
    """Code d'accès partagé (si DIKEVIA_DEMO_TOKEN est défini) + limite de débit par IP."""
    if not token_is_valid(settings.dikevia_demo_token, request.headers.get("x-demo-token")):
        raise HTTPException(status_code=401, detail="Code d'accès invalide ou manquant.")
    key = client_key(request.headers.get("x-forwarded-for"), request.client.host if request.client else None)
    if not limiter.allow(key):
        raise HTTPException(status_code=429, detail="Trop de demandes : patientez une minute.")


class ChatQuestion(BaseModel):
    question: str = Field(min_length=8, max_length=5000)
    facts_date: str | None = None
    history: list[dict[str, Any]] = Field(default_factory=list, max_length=12)
    selected_source_keys: list[str] | None = Field(default=None, max_length=12)


@app.exception_handler(RequestValidationError)
async def validation_error(_: Request, exc: RequestValidationError):
    fields = {str(e.get("loc", [""])[-1]) for e in exc.errors()}
    if "question" in fields:
        message = "La question doit contenir entre 8 et 5000 caractères."
    else:
        message = "Requête invalide : vérifiez les champs envoyés."
    return JSONResponse(status_code=422, content={"detail": message})


@app.get("/health")
async def health():
    return {"status": "ok", "mode": "local-development", "database": "not-used"}


@app.get("/api/v1/status", dependencies=[Depends(require_access)])
async def status():
    """État des briques externes, sans jamais exposer de secret."""
    try:
        snapshot = search_cgfp("congé", limit=1)["source"]
        cgfp = {"available": True, "article_count": snapshot.get("article_count"),
                "snapshot_modified_at": snapshot.get("snapshot_modified_at"),
                "source_id": snapshot.get("source_id")}
    except Exception:  # index absent ou invalide
        cgfp = {"available": False}
    return {
        "cgfp_index": cgfp,
        "legifrance": {"configured": legifrance.configured, "environment": legifrance.environment},
        "ai": {"configured": bool(settings.ai_api_base_url and settings.ai_api_key and settings.ai_model)},
        "database": "not-used",
    }


@app.post("/api/v1/chat/ask", dependencies=[Depends(require_access)])
async def ask(payload: ChatQuestion):
    request = AskRequest(employer="NATIONAL", facts_date=payload.facts_date, question=payload.question)
    history = [
        {"role": m["role"], "content": str(m.get("content", ""))[:5000]}
        for m in payload.history if m.get("role") in {"user", "assistant"}
    ]
    try:
        result = await orchestrator.ask(
            request, organization_id="CHATBOT_V1_LOCAL_ONLY", conn=None, conversation_history=history,
                selected_source_keys=payload.selected_source_keys,
        )
    except Exception:
        # Le détail technique reste dans les journaux serveur, jamais dans la réponse.
        logger.exception("Échec inattendu du moteur juridique")
        return JSONResponse(status_code=500, content={
            "detail": "Le moteur juridique a rencontré une erreur inattendue. Aucune réponse n'est produite ; réessayez."})
    return result.model_dump(exclude={"ai_usage"})


@app.get("/")
async def home():
    return FileResponse(FRONTEND / "index.html")


app.mount("/static", StaticFiles(directory=FRONTEND), name="static")
