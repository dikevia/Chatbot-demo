import unittest
from app.guard import RateLimiter, client_key, parse_origins, token_is_valid


class Guard(unittest.TestCase):
    def test_token(self):
        self.assertTrue(token_is_valid("", None))
        self.assertTrue(token_is_valid("abc", "abc"))
        self.assertFalse(token_is_valid("abc", "abd"))
        self.assertFalse(token_is_valid("abc", None))
        self.assertFalse(token_is_valid("abc", ""))

    def test_rate_limit_window(self):
        r = RateLimiter(3, 60)
        self.assertTrue(all(r.allow("ip", t) for t in (0, 1, 2)))
        self.assertFalse(r.allow("ip", 3))
        self.assertTrue(r.allow("autre", 3))
        self.assertTrue(r.allow("ip", 61))

    def test_rate_limit_disabled(self):
        r = RateLimiter(0)
        self.assertTrue(all(r.allow("ip", 0) for _ in range(100)))

    def test_client_key_uses_proxy_hop_not_spoofed_first(self):
        self.assertEqual(client_key("6.6.6.6, 203.0.113.9", "10.0.0.1"), "203.0.113.9")
        self.assertEqual(client_key(None, "10.0.0.1"), "10.0.0.1")

    def test_origins(self):
        self.assertEqual(parse_origins("https://a.fr/, capacitor://localhost ,"), ["https://a.fr", "capacitor://localhost"])


if __name__ == "__main__":
    unittest.main()
