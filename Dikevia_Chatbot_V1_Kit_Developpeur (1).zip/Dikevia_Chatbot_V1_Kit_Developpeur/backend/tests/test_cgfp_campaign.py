"""Campagne de recherche CGFP sans réseau ni dépendance externe (unittest, exécutable partout).
Vérifie la mécanique (références réelles, abstention) — PAS la justesse juridique des résultats."""
import re
import unittest

from app.cgfp import get_cgfp_article, search_cgfp

THEMES = {
    "congés annuels": "congé annuel d'un agent territorial combien de jours",
    "maladie": "arrêt maladie ordinaire traitement fonctionnaire",
    "temps de travail": "durée du temps de travail 1607 heures",
    "heures supplémentaires": "heures supplémentaires indemnisation",
    "rémunération et primes": "régime indemnitaire primes traitement indiciaire",
    "avancement": "avancement de grade promotion interne",
    "discipline": "sanction disciplinaire conseil de discipline",
    "droit syndical": "droit syndical décharge d'activité",
    "employeur": "obligation de protection fonctionnelle de l'employeur",
}


class Campagne(unittest.TestCase):
    def test_chaque_theme_retourne_des_articles_reels_et_sources(self):
        for nom, q in THEMES.items():
            res = search_cgfp(q, limit=5)["results"]
            self.assertTrue(res, nom)
            for r in res:
                self.assertRegex(r["article"], r"^[LDR]\d+(-\d+)+$")
                self.assertIsNotNone(get_cgfp_article(r["article"]), r["article"])
                self.assertTrue(r["excerpt"] and r["page_start"] >= 1)

    def test_reference_inexistante_pas_de_resultat_invente(self):
        r = search_cgfp("article L. 9999-99", limit=5)
        self.assertEqual(r["results"], [])
        self.assertEqual(r["unknown_refs"], ["L9999-99"])

    def test_reference_existante_en_premier(self):
        r = search_cgfp("que dit l'article L. 121-1 ?", limit=3)
        self.assertEqual(r["results"][0]["article"], "L121-1")
        self.assertEqual(r["unknown_refs"], [])

    def test_fragment_banal_nest_pas_une_reference(self):
        self.assertEqual(search_cgfp("j'ai d 5 jours de congé", limit=3)["unknown_refs"], [])

    def test_question_vide_ou_sans_mot_utile(self):
        self.assertEqual(search_cgfp("???", limit=3)["results"], [])


if __name__ == "__main__":
    unittest.main()


class ArticlesSansTiret(unittest.TestCase):
    """Régression : L4 est un article valide du CGFP (sans tiret)."""

    def test_article_l4(self):
        r = search_cgfp("Article L4", limit=5)
        self.assertEqual(r["results"][0]["article"], "L4")
        self.assertEqual(r["results"][0]["page_start"], 1)
        self.assertIn("fonctionnaires territoriaux", r["results"][0]["excerpt"])
        self.assertEqual(r["unknown_refs"], [])

    def test_article_sans_tiret_inexistant_signale(self):
        self.assertEqual(search_cgfp("article L99999999", limit=3)["unknown_refs"], ["L99999999"])
