from app.cgfp import search_cgfp, get_cgfp_article
from app.legal_validation import parse_facts_date


def test_cgfp_index_is_available_and_returns_articles():
    result = search_cgfp("congé annuel fonction publique", limit=5)
    assert result["source"]["source_id"] == "FR-CGFP-2026-10-31"
    assert result["results"]
    assert all(item.get("article") and item.get("excerpt") for item in result["results"])


def test_article_lookup_uses_index_reference():
    result = search_cgfp("L. 621-1", limit=1)
    if result["results"]:
        article = get_cgfp_article(result["results"][0]["article"])
        assert article and article["text"]


def test_facts_date_is_strict_iso():
    assert parse_facts_date("2026-11-17").isoformat() == "2026-11-17"
    try:
        parse_facts_date("17/11/2026")
    except ValueError:
        pass
    else:
        raise AssertionError("A date outside strict ISO format must be rejected")
