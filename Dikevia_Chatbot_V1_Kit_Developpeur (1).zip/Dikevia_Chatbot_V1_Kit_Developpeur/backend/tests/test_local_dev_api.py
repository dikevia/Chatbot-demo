from fastapi.testclient import TestClient
from dev_main import app


def test_local_health_is_database_free():
    with TestClient(app) as client:
        response = client.get('/health')
    assert response.status_code == 200
    assert response.json()['database'] == 'not-used'


def test_invalid_facts_date_fails_closed_without_database():
    with TestClient(app) as client:
        response = client.post('/api/v1/chat/ask', json={
            'question': 'Quels sont mes droits concernant mes congés annuels ?',
            'facts_date': '17/11/2026',
            'history': [],
        })
    assert response.status_code == 200
    data = response.json()
    assert data['verification_status'] == 'NON_VERIFIE'
    assert 'AAAA-MM-JJ' in data['missing_information'][0]
