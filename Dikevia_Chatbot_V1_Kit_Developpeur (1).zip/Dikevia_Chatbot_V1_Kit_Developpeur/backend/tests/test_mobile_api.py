"""Tests de l'API mobile avec TestClient (nécessite fastapi : pip install -r backend/requirements-dev.txt).
CODÉS MAIS NON EXÉCUTÉS dans l'environnement de rédaction (fastapi indisponible) — à lancer avant toute démo."""
from fastapi.testclient import TestClient

import dev_main
from app.config import settings

Q = "Quels sont mes droits concernant mes congés annuels ?"


def test_status_exposes_no_secret():
    with TestClient(dev_main.app) as c:
        body = c.get("/api/v1/status").json()
    assert set(body) == {"cgfp_index", "legifrance", "ai", "database"}
    assert "secret" not in str(body).lower() and "key" not in str(body).lower().replace("configured", "")


def test_token_is_enforced_when_configured(monkeypatch):
    monkeypatch.setattr(settings, "dikevia_demo_token", "code-test")
    with TestClient(dev_main.app) as c:
        assert c.post("/api/v1/chat/ask", json={"question": Q}).status_code == 401
        assert c.post("/api/v1/chat/ask", json={"question": Q}, headers={"X-Demo-Token": "mauvais"}).status_code == 401
        ok = c.post("/api/v1/chat/ask", json={"question": Q, "facts_date": "17/11/2026"}, headers={"X-Demo-Token": "code-test"})
    assert ok.status_code == 200 and ok.json()["verification_status"] == "NON_VERIFIE"


def test_rate_limit(monkeypatch):
    monkeypatch.setattr(dev_main, "limiter", dev_main.RateLimiter(2, 60))
    with TestClient(dev_main.app) as c:
        codes = [c.get("/api/v1/status").status_code for _ in range(3)]
    assert codes == [200, 200, 429]


def test_cors_preflight_allows_android_webview_origin():
    with TestClient(dev_main.app) as c:
        r = c.options("/api/v1/chat/ask", headers={"Origin": "https://localhost",
            "Access-Control-Request-Method": "POST", "Access-Control-Request-Headers": "content-type,x-demo-token"})
    assert r.headers.get("access-control-allow-origin") == "https://localhost"


def test_short_question_gives_french_message():
    with TestClient(dev_main.app) as c:
        r = c.post("/api/v1/chat/ask", json={"question": "court"})
    assert r.status_code == 422 and "8 et 5000" in r.json()["detail"]


def test_conversation_with_history_stays_database_free():
    hist = [{"role": "user", "content": Q}, {"role": "assistant", "content": "Réponse précédente."}]
    with TestClient(dev_main.app) as c:
        r = c.post("/api/v1/chat/ask", json={"question": "Et pour un agent contractuel ?", "facts_date": "2026-13-45", "history": hist})
    assert r.status_code == 200 and r.json()["verification_status"] == "NON_VERIFIE"
