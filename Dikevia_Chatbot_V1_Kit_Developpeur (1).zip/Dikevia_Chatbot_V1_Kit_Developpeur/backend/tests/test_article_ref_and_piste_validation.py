"""Tests sans PostgreSQL ni réseau. Fonctionnent sous pytest et unittest.

La partie connecteur utilise de faux modules httpx/config uniquement si les
vrais ne sont pas installés ; aucun appel réseau n'est jamais effectué.
"""
import asyncio
import sys
import types
import unittest
from datetime import date

from app.article_ref import extract_requested_ref, own_article_number

try:
    import httpx  # noqa: F401
    from app import config  # noqa: F401
except Exception:  # environnement minimal : doublures locales
    fake_httpx = types.ModuleType("httpx")
    fake_httpx.AsyncBaseTransport = object
    sys.modules["httpx"] = fake_httpx
    fake_config = types.ModuleType("app.config")
    fake_config.settings = types.SimpleNamespace(
        legifrance_environment="sandbox", legifrance_client_id="x", legifrance_client_secret="y",
        legifrance_scope="openid", legifrance_timeout_seconds=5, legifrance_code_name="CGFP")
    sys.modules["app.config"] = fake_config

from app.legifrance import LegifranceConnector  # noqa: E402

AID = "LEGIARTI000044000001"
BID = "LEGIARTI000044000002"


class RefExtraction(unittest.TestCase):
    def test_requested_refs(self):
        self.assertEqual(extract_requested_ref("que dit l'article L. 121-1 ?"), "L121-1")
        self.assertEqual(extract_requested_ref("r123-4-1 svp"), "R123-4-1")
        self.assertEqual(extract_requested_ref("Article L4"), "L4")
        self.assertEqual(extract_requested_ref("que dit L4 ?"), "L4")

    def test_false_positives_rejected(self):
        for q in ("j'ai d 5 jours de congé", "il y a l 2 agents", "bonjour", ""):
            self.assertIsNone(extract_requested_ref(q), q)

    def test_own_number_prefers_api_field_over_cross_reference(self):
        detail = {"article": {"id": AID, "num": "L121-1",
                              "texte": "Les agents sont soumis, sous réserve de l'article L. 999-9, aux règles."}}
        self.assertEqual(own_article_number(detail, AID, detail["article"]["texte"]), "L121-1")

    def test_cross_reference_in_body_is_not_the_number(self):
        detail = {"article": {"id": AID, "texte": "Conformément à l'article L. 999-9 le texte s'applique."}}
        self.assertIsNone(own_article_number(detail, AID, detail["article"]["texte"]))

    def test_leading_reference_fallback(self):
        text = "Article L121-1 Le fonctionnaire est tenu à l'obligation de dignité."
        self.assertEqual(own_article_number({"article": {"id": AID}}, AID, text), "L121-1")


class ConnectorValidation(unittest.TestCase):
    def _run(self, query, details):
        c = LegifranceConnector()

        async def fake_request(method, path, json_body=None, **kw):
            if path == "/search":
                return {"results": [{"id": AID}, {"id": BID}]}
            return details[json_body["id"]]
        c._request = fake_request
        return asyncio.run(c.search_code_articles(query, date(2024, 5, 1)))

    def test_valid_article_with_cross_reference_is_kept(self):
        long = "Texte de l'article avec renvoi à l'article L. 999-9 et contenu suffisant."
        out = self._run("article L121-1", {
            AID: {"article": {"id": AID, "num": "L121-1", "texte": long}},
            BID: {"article": {"id": BID, "num": "L121-2", "texte": long}}})
        self.assertEqual([a["article"] for a in out], ["L121-1"])
        self.assertTrue(out[0]["official_source"])

    def test_article_without_provable_number_is_dropped_when_ref_requested(self):
        long = "Un renvoi à l'article L121-1 figure ici mais ce n'est pas le numéro propre."
        out = self._run("article L121-1", {
            AID: {"article": {"id": AID, "texte": long}},
            BID: {"article": {"id": BID, "texte": long}}})
        self.assertEqual(out, [])


if __name__ == "__main__":
    unittest.main()
