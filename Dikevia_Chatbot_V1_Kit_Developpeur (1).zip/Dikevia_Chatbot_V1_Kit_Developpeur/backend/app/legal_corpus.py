"""Stockage, historisation et recherche du corpus juridique national JURIS.

Les documents sont des sources publiques communes à tous les tenants. Les imports
conservent les identifiants de la source, les dates, le statut et le texte réellement
récupéré. Les champs absents restent NULL/UNKNOWN : aucune métadonnée n'est inventée.
"""
from __future__ import annotations

import hashlib
import json
import html
import re
from datetime import date
from typing import Any
from urllib.parse import urlparse

CHUNK_SIZE = 4200
CHUNK_OVERLAP = 300


def sha256_text(value: str) -> str:
    return hashlib.sha256(value.encode("utf-8")).hexdigest()


def clean_text(value: str) -> str:
    value = re.sub(r"<br\s*/?>", "\n", value, flags=re.I)
    value = re.sub(r"</(?:p|div|li|h[1-6]|tr)\s*>", "\n", value, flags=re.I)
    value = re.sub(r"<[^>]+>", " ", value)
    value = html.unescape(value)
    value = re.sub(r"[ \t\u00a0]+", " ", value)
    value = re.sub(r"\n\s*\n+", "\n\n", value)
    return value.strip()


def split_text(text: str, size: int = CHUNK_SIZE, overlap: int = CHUNK_OVERLAP) -> list[str]:
    text = text.strip()
    if not text:
        return []
    chunks: list[str] = []
    start = 0
    while start < len(text):
        end = min(len(text), start + size)
        if end < len(text):
            boundary = text.rfind("\n", start + size // 2, end)
            if boundary > start:
                end = boundary
        piece = text[start:end].strip()
        if piece:
            chunks.append(piece)
        if end >= len(text):
            break
        start = max(start + 1, end - overlap)
    return chunks


def temporal_status(valid_from: date | None, valid_to: date | None, requested: date,
                    document_kind: str | None = None, signature_date: date | None = None,
                    raw_payload: dict | None = None, version_status: str | None = None) -> str:
    if document_kind == "ADMIN_CASELAW":
        if not signature_date:
            return "TEMPORAL_SCOPE_INCOMPLETE"
        return "DECISION_AVAILABLE_BY_REQUESTED_DATE" if signature_date <= requested else "DECISION_POSTERIOR_TO_REQUESTED_DATE"
    if document_kind in {"CODE", "LAW", "ORDONNANCE", "DECREE", "ORDER"}:
        if isinstance(raw_payload, str):
            try:
                raw_payload = json.loads(raw_payload)
            except (ValueError, TypeError):
                raw_payload = {}
        imported_for_date = (raw_payload or {}).get("requested_date") == requested.isoformat()
        if imported_for_date and version_status == "IN_FORCE":
            return "IN_FORCE_ON_REQUESTED_DATE"
        if imported_for_date and version_status in {"REPEALED", "NOT_IN_FORCE"}:
            return "NO_LONGER_IN_FORCE"
    if valid_from and requested < valid_from:
        return "NOT_YET_EFFECTIVE"
    if valid_to and requested > valid_to:
        return "NO_LONGER_IN_FORCE"
    if valid_from and valid_to:
        return "IN_FORCE_ON_REQUESTED_DATE"
    return "TEMPORAL_SCOPE_INCOMPLETE"


def safe_official_url(value: str | None) -> str | None:
    if not value:
        return None
    parsed = urlparse(value)
    if parsed.scheme == "https" and parsed.hostname in {"www.legifrance.gouv.fr", "legifrance.gouv.fr"}:
        return value[:1500]
    return None


async def upsert_legal_document(conn, item: dict[str, Any]) -> dict[str, Any]:
    required = ("source_type", "source_id", "title", "document_kind")
    if any(not isinstance(item.get(k), str) or not item[k].strip() for k in required):
        raise ValueError("Métadonnées minimales de source juridique manquantes.")
    text = clean_text(str(item.get("full_text") or ""))
    text_hash = sha256_text(text) if text else None
    url = safe_official_url(item.get("official_url"))
    metadata = item.get("raw_metadata") if isinstance(item.get("raw_metadata"), dict) else {}
    doc = await conn.fetchrow("""
      INSERT INTO legal_documents(source_type,source_id,title,document_kind,official_number,jurisdiction,publisher,
        official_url,signature_date,publication_date,status,source_status,raw_metadata,content_sha256,last_seen_at)
      VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13::jsonb,$14,now())
      ON CONFLICT(source_type,source_id) DO UPDATE SET title=EXCLUDED.title,
        document_kind=EXCLUDED.document_kind,official_number=COALESCE(EXCLUDED.official_number,legal_documents.official_number),
        jurisdiction=COALESCE(EXCLUDED.jurisdiction,legal_documents.jurisdiction),
        publisher=COALESCE(EXCLUDED.publisher,legal_documents.publisher),
        official_url=COALESCE(EXCLUDED.official_url,legal_documents.official_url),
        signature_date=COALESCE(EXCLUDED.signature_date,legal_documents.signature_date),
        publication_date=COALESCE(EXCLUDED.publication_date,legal_documents.publication_date),
        status=CASE WHEN EXCLUDED.status='UNKNOWN' THEN legal_documents.status ELSE EXCLUDED.status END,
        source_status=EXCLUDED.source_status,raw_metadata=legal_documents.raw_metadata || EXCLUDED.raw_metadata,
        content_sha256=COALESCE(EXCLUDED.content_sha256,legal_documents.content_sha256),last_seen_at=now()
      RETURNING id
    """, item["source_type"], item["source_id"], item["title"][:1000], item["document_kind"],
        item.get("official_number"), item.get("jurisdiction"), item.get("publisher"), url,
        item.get("signature_date"), item.get("publication_date"), item.get("status", "UNKNOWN"),
        item.get("source_status", "METADATA_ONLY"), __import__("json").dumps(metadata, ensure_ascii=False), text_hash)
    version_key = str(item.get("version_key") or (text_hash or "metadata-" + str(item.get("source_id"))))[:180]
    version = await conn.fetchrow("""
      INSERT INTO legal_document_versions(document_id,version_key,source_version_id,valid_from,valid_to,
        version_status,full_text,text_sha256,raw_payload)
      VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9::jsonb)
      ON CONFLICT(document_id,version_key) DO UPDATE SET
        full_text=CASE WHEN EXCLUDED.full_text<>'' THEN EXCLUDED.full_text ELSE legal_document_versions.full_text END,
        text_sha256=COALESCE(EXCLUDED.text_sha256,legal_document_versions.text_sha256),
        valid_from=COALESCE(EXCLUDED.valid_from,legal_document_versions.valid_from),
        valid_to=COALESCE(EXCLUDED.valid_to,legal_document_versions.valid_to),
        version_status=CASE WHEN EXCLUDED.version_status='UNKNOWN' THEN legal_document_versions.version_status ELSE EXCLUDED.version_status END,
        raw_payload=legal_document_versions.raw_payload || EXCLUDED.raw_payload,retrieved_at=now()
      RETURNING id
    """, doc["id"], version_key, item.get("source_version_id"), item.get("valid_from"), item.get("valid_to"),
        item.get("version_status", "UNKNOWN"), text, text_hash,
        __import__("json").dumps(item.get("raw_version_payload") or {}, ensure_ascii=False))
    await conn.execute("DELETE FROM legal_chunks WHERE version_id=$1", version["id"])
    if text:
        chunks = split_text(text)
        for ordinal, chunk in enumerate(chunks):
            await conn.execute("INSERT INTO legal_chunks(version_id,ordinal,anchor,content_kind,content) VALUES($1,$2,$3,'FULL_TEXT',$4)",
                version["id"], ordinal, item.get("anchor"), chunk)
    else:
        metadata_text = " — ".join(str(x) for x in (item.get("title"), item.get("official_number"), item.get("publisher")) if x)
        if metadata_text:
            await conn.execute("INSERT INTO legal_chunks(version_id,ordinal,anchor,content_kind,content) VALUES($1,0,$2,'METADATA',$3)",
                version["id"], item.get("anchor"), metadata_text[:4000])
    return {"document_id": str(doc["id"]), "version_id": str(version["id"]), "chunks": len(split_text(text)) if text else (1 if item.get("title") else 0),
            "text_imported": bool(text)}


async def search_legal_corpus(conn, query: str, requested_date: date, limit: int = 12) -> list[dict]:
    if not isinstance(query, str) or len(query.strip()) < 2 or len(query) > 500:
        raise ValueError("La recherche documentaire doit contenir entre 2 et 500 caractères.")
    if not 1 <= limit <= 30:
        raise ValueError("La limite doit être comprise entre 1 et 30.")
    rows = await conn.fetch("""
      WITH ranked AS (
        SELECT d.id document_id,v.id version_id,d.source_type,d.source_id,d.title,d.document_kind,
          d.official_number,d.jurisdiction,d.official_url,d.signature_date,d.publication_date,d.status document_status,
          d.source_status,v.valid_from,v.valid_to,v.version_status,v.raw_payload,v.full_text,v.text_sha256,c.anchor,c.content,c.content_kind,
          ts_rank_cd(c.search_vector,websearch_to_tsquery('french',$1)) rank,
          row_number() OVER(PARTITION BY v.id ORDER BY ts_rank_cd(c.search_vector,websearch_to_tsquery('french',$1)) DESC,c.ordinal) rn
        FROM legal_chunks c JOIN legal_document_versions v ON v.id=c.version_id
        JOIN legal_documents d ON d.id=v.document_id
        WHERE c.search_vector @@ websearch_to_tsquery('french',$1)
      )
      SELECT * FROM ranked WHERE rn=1 ORDER BY rank DESC,publication_date DESC NULLS LAST LIMIT $2
    """, query.strip(), limit)
    results = []
    for row in rows:
        item = dict(row)
        item["temporal_status"] = temporal_status(item.get("valid_from"), item.get("valid_to"), requested_date,
            item.get("document_kind"), item.get("signature_date"), item.get("raw_payload"), item.get("version_status"))
        item["requested_date"] = requested_date.isoformat()
        item["source_id"] = item.pop("source_id")
        item["source_type"] = item.pop("source_type")
        item["excerpt"] = item.pop("content")[:2200]
        item["content_kind"] = item.get("content_kind")
        full_text = item.pop("full_text")
        expected_hash = item.pop("text_sha256")
        actual_hash = sha256_text(full_text) if full_text else None
        hash_verified = bool(expected_hash and actual_hash and expected_hash.strip() == actual_hash)
        item.pop("raw_payload", None)
        item["full_text"] = full_text if hash_verified else ""
        item["official_source"] = item.get("source_status") in {
            "OFFICIAL_TEXT_RETRIEVED", "OFFICIAL_TEXT_ID_VERIFIED", "OFFICIAL_XML_IMPORTED", "MANUALLY_VERIFIED"}
        item["citation_integrity"] = {"valid": bool(item["source_id"] and item["source_status"] and hash_verified and item.get("content_kind") == "FULL_TEXT"),
            "verification_scope": "SOURCE_ID_AND_STORED_VERSION", "text_hash_verified": hash_verified,
            "temporal_status": item["temporal_status"]}
        results.append(item)
    return results
