"""Références d'articles du CGFP (L123-4, R. 123-4-1…) — module sans dépendance.

Références du CGFP : L121-1, R. 123-4-1, mais aussi des articles sans tiret (L4).
Les formes ambiguës (« d 5 jours ») ne sont pas prises pour des articles.
"""
from __future__ import annotations

import re
from typing import Any

# Trois formes acceptées (le CGFP contient des articles sans tiret, comme L4) :
#  1. avec tiret : L121-1, R. 123-4-1 ;  2. sans tiret mais précédé du mot « article » ;
#  3. sans tiret, lettre MAJUSCULE collée aux chiffres : L4.
# « d 5 jours » ou « l 2 agents » ne sont donc jamais pris pour des articles.
_ALT = (r"(?:article\s+)?([LDR]\.?\s*\d+(?:-\d+)+)"
        r"|article\s+([LDR]\.?\s*\d+)"
        r"|((?-i:[LDR])\d+)")
REF_RE = re.compile(r"(?<![A-Za-z0-9])(?:" + _ALT + r")(?![\w-])", re.I)
_LEADING_REF_RE = re.compile(r"^\s*(?:<[^>]+>\s*)*(?:" + _ALT + r")(?![\w-])", re.I)
_NUMBER_KEYS = ("num", "number", "numero", "numeroarticle")


def _first_group(match) -> str:
    return next(g for g in match.groups() if g)


def normalize_ref(raw: str) -> str:
    return re.sub(r"[.\s]+", "", raw).upper()


def extract_requested_ref(query: str) -> str | None:
    """Référence d'article explicitement demandée par l'utilisateur, normalisée."""
    match = REF_RE.search(query or "")
    return normalize_ref(_first_group(match)) if match else None


def find_refs(text: str) -> list[str]:
    """Toutes les références normalisées trouvées dans le texte (ordre d'apparition, sans doublon)."""
    return list(dict.fromkeys(normalize_ref(_first_group(m)) for m in REF_RE.finditer(text or "")))


def strip_refs(text: str) -> str:
    """Texte sans les références d'articles (pour ne pas les traiter comme des mots-clés)."""
    return REF_RE.sub(" ", text or "")


def own_article_number(detail: Any, article_id: str, text: str) -> str | None:
    """Numéro propre de l'article retourné par l'API.

    Priorité au champ de numéro du nœud portant l'identifiant demandé ; à défaut,
    seule une référence placée au tout début du texte est acceptée. Un renvoi
    vers un autre article cité plus loin dans le texte n'est jamais pris pour
    le numéro de l'article.
    """
    stack = [detail]
    while stack:
        node = stack.pop()
        if isinstance(node, dict):
            if node.get("id") == article_id or node.get("idArticle") == article_id:
                for key, value in node.items():
                    if key.lower() in _NUMBER_KEYS and isinstance(value, (str, int)):
                        found = REF_RE.fullmatch(str(value).strip())
                        if found:
                            return normalize_ref(_first_group(found))
            stack.extend(node.values())
        elif isinstance(node, list):
            stack.extend(node)
    leading = _LEADING_REF_RE.match(text or "")
    return normalize_ref(_first_group(leading)) if leading else None
