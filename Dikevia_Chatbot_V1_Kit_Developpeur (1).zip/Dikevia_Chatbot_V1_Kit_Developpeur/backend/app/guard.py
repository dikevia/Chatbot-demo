"""Protection minimale d'un serveur de démonstration exposé sur Internet.

Sans cela, n'importe qui connaissant l'adresse pourrait consommer le quota IA/PISTE.
Ce n'est PAS un système de comptes : un seul code partagé, des limites par adresse IP.
"""
from __future__ import annotations

import hmac
import time
from collections import defaultdict, deque


def token_is_valid(expected: str, provided: str | None) -> bool:
    """Sans code attendu, l'accès est libre (usage local). Comparaison à temps constant."""
    if not expected:
        return True
    return hmac.compare_digest(expected.encode(), (provided or "").encode())


class RateLimiter:
    def __init__(self, max_calls: int, window_seconds: float = 60.0):
        self.max_calls, self.window = max_calls, window_seconds
        self._hits: dict[str, deque] = defaultdict(deque)

    def allow(self, key: str, now: float | None = None) -> bool:
        if self.max_calls <= 0:
            return True
        now = time.monotonic() if now is None else now
        hits = self._hits[key]
        while hits and now - hits[0] >= self.window:
            hits.popleft()
        if len(hits) >= self.max_calls:
            return False
        hits.append(now)
        if len(self._hits) > 5000:  # borne mémoire
            for k in [k for k, v in self._hits.items() if not v]:
                del self._hits[k]
        return True


def client_key(forwarded_for: str | None, peer: str | None) -> str:
    """Derrière un proxy d'hébergement, la dernière adresse X-Forwarded-For est celle ajoutée par le proxy."""
    if forwarded_for:
        last = forwarded_for.split(",")[-1].strip()
        if last:
            return last
    return peer or "unknown"


def parse_origins(value: str) -> list[str]:
    return [o.strip().rstrip("/") for o in (value or "").split(",") if o.strip()]
