// Copie frontend/ vers www/ et écrit config.js avec l'adresse HTTPS du serveur (variable DIKEVIA_API_BASE).
// Aucun secret n'est écrit : seule l'adresse publique du serveur.
const fs = require("fs"), path = require("path");
const root = path.resolve(__dirname, ".."), src = path.join(root, "frontend"), dst = path.join(root, "www");
const base = (process.env.DIKEVIA_API_BASE || "").trim().replace(/\/+$/, "");
if (base && !/^https:\/\/[A-Za-z0-9.-]+(:\d+)?(\/[\w./-]*)?$/.test(base)) {
  console.error("DIKEVIA_API_BASE invalide : une adresse https://… sans identifiant ni paramètre est exigée."); process.exit(1);
}
fs.rmSync(dst, { recursive: true, force: true });
fs.cpSync(src, dst, { recursive: true });
fs.writeFileSync(path.join(dst, "config.js"), "window.DIKEVIA_CONFIG = " + JSON.stringify({ apiBase: base }) + ";\n");
console.log("www prêt — serveur : " + (base || "(à saisir dans l'application)"));
