from pathlib import Path
import hashlib, json, sys
ROOT=Path(__file__).resolve().parents[1]
meta=json.loads((ROOT/'corpus_national/legislation/CGFP_snapshot_2026-10-31.metadata.json').read_text(encoding='utf-8'))
pdf=ROOT/'corpus_national/legislation/CGFP_snapshot_2026-10-31.pdf'
index=json.loads((ROOT/'corpus_national/index/CGFP_articles_2026-10-31.json').read_text(encoding='utf-8'))
actual=hashlib.sha256(pdf.read_bytes()).hexdigest()
assert actual==meta['sha256'], 'SHA-256 du PDF différent des métadonnées'
assert index['source_id']==meta['source_id'], 'source_id index/métadonnées différent'
assert index['source_sha256']==actual, 'empreinte index/PDF différente'
assert len(index['articles'])>0, 'index vide'
print(f"OK — PDF conforme, {len(index['articles'])} articles indexés, SHA-256 {actual}")
