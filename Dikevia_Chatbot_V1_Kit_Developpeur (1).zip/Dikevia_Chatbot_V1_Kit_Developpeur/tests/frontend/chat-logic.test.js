const test = require("node:test"), assert = require("node:assert");
const L = require("../../frontend/chat-logic.js");
const mem = () => { const d = {}; return { getItem: k => (k in d ? d[k] : null), setItem: (k, v) => { d[k] = v; }, d }; };

test("erreurs 422 de type tableau lisibles (plus de [object Object])", () => {
  assert.strictEqual(L.formatErrorDetail([{ msg: "trop court" }]), "trop court");
  assert.strictEqual(L.formatErrorDetail("x"), "x");
});
test("statuts", () => { assert.strictEqual(L.statusInfo("NON_VERIFIE").tone, "bad"); assert.strictEqual(L.statusInfo("???").label, "Statut inconnu"); });
test("question", () => { assert.ok(!L.validateQuestion("court").ok); assert.ok(L.validateQuestion("  une vraie question  ").ok); assert.ok(!L.validateQuestion("a".repeat(5001)).ok); });
test("date des faits", () => {
  assert.deepStrictEqual(L.validateFactsDate(""), { ok: true, value: null });
  assert.ok(L.validateFactsDate("2026-11-17").ok);
  assert.ok(!L.validateFactsDate("17/11/2026").ok);
  assert.ok(!L.validateFactsDate("2026-02-30").ok);
});
test("adresse serveur : https obligatoire sauf localhost", () => {
  assert.strictEqual(L.normalizeApiBase("https://x.onrender.com/").value, "https://x.onrender.com");
  assert.ok(!L.normalizeApiBase("http://x.onrender.com").ok);
  assert.ok(L.normalizeApiBase("http://localhost:8000").ok);
  assert.ok(!L.normalizeApiBase("javascript:alert(1)").ok);
  assert.ok(!L.normalizeApiBase("https://u:p@x.com").ok);
  assert.strictEqual(L.normalizeApiBase("").value, "");
});
test("historique : 12 derniers, rôles valides, tronqué", () => {
  const msgs = Array.from({ length: 20 }, (_, i) => ({ role: i % 2 ? "assistant" : "user", content: "m" + i }));
  msgs.push({ role: "system", content: "x" }, { role: "user", content: "z".repeat(9000) });
  const h = L.buildHistory(msgs, 12);
  assert.strictEqual(h.length, 12); assert.ok(h.every(m => m.role !== "system")); assert.strictEqual(h[11].content.length, 5000);
});
test("messages d'erreur réseau", () => {
  assert.match(L.friendlyNetworkError(null, 0), /Impossible de joindre/);
  assert.match(L.friendlyNetworkError(null, 401), /code d'accès/);
  assert.match(L.friendlyNetworkError(null, 429), /Trop de demandes/);
  assert.strictEqual(L.friendlyNetworkError(null, 500, "boom"), "boom");
});
test("conversations multiples, titre, sélection, suppression, persistance", () => {
  const st = mem(), s = L.createStore(st, "k"); s.load();
  const a = s.newConversation();
  s.addMessage({ role: "user", content: "Combien de jours de congés annuels ai-je ?" });
  s.addMessage({ role: "assistant", content: "…", sources: [] });
  assert.match(s.current().title, /^Combien de jours/);
  const b = s.newConversation(); assert.notStrictEqual(a.id, b.id);
  assert.strictEqual(s.newConversation().id, b.id, "pas de conversation vide en double");
  s.addMessage({ role: "user", content: "Question sur les sanctions disciplinaires" });
  const s2 = L.createStore(st, "k"); s2.load();
  assert.strictEqual(s2.state.conversations.length, 2);
  s2.select(a.id); assert.strictEqual(s2.current().messages.length, 2);
  s2.remove(a.id); assert.strictEqual(s2.state.conversations.length, 1);
  s2.clearAll(); assert.strictEqual(s2.current(), null);
});
test("stockage corrompu ou plein : ne plante pas", () => {
  const bad = { getItem: () => "{pas du json", setItem: () => { throw new Error("quota"); } };
  const s = L.createStore(bad, "k"); s.load(); s.newConversation(); s.addMessage({ role: "user", content: "question valable" });
  assert.strictEqual(s.current().messages.length, 1);
});
test("sources : extraits bornés, lien officiel conservé", () => {
  const t = L.trimSources([{ source_type: "LEGIFRANCE_API", excerpt: "x".repeat(5000), source_url: "https://www.legifrance.gouv.fr/" }]);
  assert.strictEqual(t[0].excerpt.length, 800); assert.ok(t[0].official_url);
});
