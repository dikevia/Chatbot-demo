/* Interface mobile Dikevia — rendu 100 % via textContent (aucun innerHTML). */
(function () {
  "use strict";
  const L = window.DikeviaLogic;
  const $ = id => document.getElementById(id);
  const LS = { base: "dikevia.apiBase", token: "dikevia.token", store: "dikevia.conversations.v1" };
  const EXAMPLES = [
    "Combien de jours de congés annuels a un agent territorial à temps complet ?",
    "Quelles sont les règles du congé de maladie ordinaire pour un fonctionnaire ?",
    "Un agent peut-il refuser d'effectuer des heures supplémentaires ?",
    "Quelles sanctions disciplinaires existent et quelle procédure suivre ?",
    "Quels sont les droits d'un représentant syndical (décharge d'activité) ?",
  ];
  const store = L.createStore(window.localStorage, LS.store);
  let busy = false;

  const get = k => { try { return localStorage.getItem(k) || ""; } catch (e) { return ""; } };
  const set = (k, v) => { try { v ? localStorage.setItem(k, v) : localStorage.removeItem(k); } catch (e) {} };
  const apiBase = () => get(LS.base) || (window.DIKEVIA_CONFIG && window.DIKEVIA_CONFIG.apiBase) || "";
  const headers = () => { const h = { "Content-Type": "application/json" }; const t = get(LS.token); if (t) h["X-Demo-Token"] = t; return h; };

  async function api(path, options, timeoutMs) {
    const ctl = new AbortController(), timer = setTimeout(() => ctl.abort(), timeoutMs || 100000);
    try {
      const r = await fetch(apiBase() + path, Object.assign({ headers: headers(), signal: ctl.signal }, options || {}));
      let data = null; try { data = await r.json(); } catch (e) {}
      return { status: r.status, ok: r.ok, data };
    } finally { clearTimeout(timer); }
  }

  function el(tag, cls, text) { const e = document.createElement(tag); if (cls) e.className = cls; if (text != null) e.textContent = text; return e; }
  function safeUrl(u) {
    try { const x = new URL(u); return x.protocol === "https:" && (x.hostname === "www.legifrance.gouv.fr" || x.hostname.endsWith(".legifrance.gouv.fr")) ? x.href : null; }
    catch (e) { return null; }
  }

  function renderSources(sources) {
    const d = el("details"); d.append(el("summary", null, "Sources juridiques (" + sources.length + ")"));
    const box = el("div");
    sources.forEach(s => {
      const w = el("div", "src");
      w.append(el("b", null, (s.title || s.source_id || "Source") + (s.article && !(s.title || "").includes(s.article) ? " — " + s.article : "")));
      const t = L.temporalInfo(s.temporal_status);
      w.append(el("span", "kind", L.sourceKind(s) + " · " + t.label + (s.page_start ? " · pages " + s.page_start + "–" + s.page_end : "")));
      if (s.excerpt) w.append(el("p", null, s.excerpt));
      const url = safeUrl(s.official_url);
      if (url) { const a = el("a", null, "Consulter sur Légifrance"); a.href = url; a.target = "_blank"; a.rel = "noopener noreferrer"; w.append(a); }
      box.append(w);
    });
    d.append(box); return d;
  }

  function renderMissing(items) {
    const d = el("details"); d.open = items.length <= 3; d.append(el("summary", null, "Points à vérifier (" + items.length + ")"));
    const box = el("div"), ul = el("ul", "miss"); items.forEach(i => ul.append(el("li", null, i))); box.append(ul); d.append(box); return d;
  }

  function renderMessage(m) {
    const row = el("div", "msg " + (m.role === "user" ? "user" : "assistant"));
    if (m.role === "assistant" && m.status) {
      const si = L.statusInfo(m.status), head = el("div");
      head.append(el("span", "badge " + si.tone, si.label)); row.append(head);
    }
    row.append(el("div", "bubble", m.content));
    if (m.role === "assistant") {
      const extra = el("div", "extra");
      if (m.sources && m.sources.length) extra.append(renderSources(m.sources));
      if (m.missing && m.missing.length) extra.append(renderMissing(m.missing));
      if (extra.childNodes.length) row.append(extra);
    }
    return row;
  }

  function renderAll() {
    const c = store.current(), box = $("messages"); box.replaceChildren();
    const msgs = c ? c.messages : [];
    $("welcome").hidden = msgs.length > 0;
    msgs.forEach(m => box.append(renderMessage(m)));
    $("chat").scrollTop = $("chat").scrollHeight;
  }

  function renderConversations() {
    const ul = $("convList"); ul.replaceChildren();
    store.state.conversations.forEach(c => {
      const li = el("li"), pick = el("button", "pick" + (c.id === store.state.current ? " on" : ""), c.title);
      pick.onclick = () => { store.select(c.id); renderAll(); closeDrawer(); };
      const del = el("button", "del", "🗑"); del.setAttribute("aria-label", "Supprimer");
      del.onclick = () => { if (confirm("Supprimer cette conversation ?")) { store.remove(c.id); renderAll(); renderConversations(); } };
      li.append(pick, del); ul.append(li);
    });
    if (!store.state.conversations.length) ul.append(el("li", "small", "Aucune conversation."));
  }

  function showError(msg) { const e = $("formError"); e.textContent = msg || ""; e.hidden = !msg; }
  function banner(text, bad) { const b = $("banner"); b.textContent = text || ""; b.hidden = !text; b.className = "banner" + (bad ? " bad" : ""); }

  async function checkStatus(showList) {
    const ul = $("statusList"); if (showList) ul.replaceChildren();
    const row = (ok, text) => { if (!showList) return; const li = el("li"); li.append(el("span", "dot " + (ok ? "ok" : "bad")), document.createTextNode(text)); ul.append(li); };
    try {
      const r = await api("/api/v1/status", { method: "GET" }, 20000);
      if (r.status === 401) { banner("Code d'accès requis ou invalide : ouvrez le menu ☰ pour le saisir.", true); row(false, "Code d'accès refusé"); return false; }
      if (!r.ok || !r.data) throw new Error("status");
      const s = r.data, notes = [];
      row(true, "Serveur joignable");
      row(!!(s.cgfp_index && s.cgfp_index.available), "Index CGFP local" + (s.cgfp_index && s.cgfp_index.article_count ? " (" + s.cgfp_index.article_count + " articles)" : ""));
      row(!!(s.legifrance && s.legifrance.configured), "Légifrance/PISTE " + (s.legifrance && s.legifrance.configured ? "configuré (" + s.legifrance.environment + ")" : "non configuré"));
      row(!!(s.ai && s.ai.configured), "Fournisseur d'IA " + (s.ai && s.ai.configured ? "configuré" : "non configuré"));
      if (!(s.legifrance && s.legifrance.configured)) notes.push("Légifrance n'est pas connecté : seules les recherches dans l'index CGFP local sont possibles, sans vérification de la version à la date des faits.");
      if (!(s.ai && s.ai.configured)) notes.push("Aucun fournisseur d'IA : les sources sont affichées sans analyse rédigée.");
      banner(notes.join(" "), false); return true;
    } catch (e) {
      banner("Serveur Dikevia injoignable. Ouvrez le menu ☰ pour vérifier l'adresse du serveur, ou réessayez dans 30 secondes s'il vient de se réveiller.", true);
      row(false, "Serveur injoignable"); return false;
    }
  }

  async function send(text) {
    if (busy) return;
    const q = L.validateQuestion(text), d = L.validateFactsDate($("factsDate").value);
    if (!q.ok) return showError(q.error);
    if (!d.ok) return showError(d.error);
    showError("");
    const conv = store.current() || store.newConversation();
    const history = L.buildHistory(conv.messages, 12);
    store.addMessage({ role: "user", content: q.value });
    renderAll(); $("question").value = ""; autosize();
    busy = true; $("btnSend").disabled = true;
    const typing = el("div", "typing", "Recherche dans le CGFP et sur Légifrance…"); $("messages").append(typing); $("chat").scrollTop = $("chat").scrollHeight;
    let reply;
    try {
      const r = await api("/api/v1/chat/ask", { method: "POST", body: JSON.stringify({ question: q.value, facts_date: d.value, history }) });
      if (r.ok && r.data) reply = { role: "assistant", content: r.data.answer || "Aucune réponse exploitable.", status: r.data.verification_status,
        sources: L.trimSources(r.data.sources), missing: (r.data.missing_information || []).slice(0, 20) };
      else reply = { role: "assistant", content: L.friendlyNetworkError(null, r.status, r.data && r.data.detail), status: "NON_VERIFIE", sources: [], missing: [] };
    } catch (e) {
      reply = { role: "assistant", content: L.friendlyNetworkError(e, 0), status: "NON_VERIFIE", sources: [], missing: [] };
    }
    store.addMessage(reply); busy = false; $("btnSend").disabled = false; renderAll();
  }

  function autosize() { const t = $("question"); t.style.height = "auto"; t.style.height = Math.min(t.scrollHeight, 140) + "px"; }
  function openDrawer() { renderConversations(); $("apiBase").value = get(LS.base) || apiBase(); $("token").value = get(LS.token); $("overlay").hidden = false; $("drawer").hidden = false; checkStatus(true); }
  function closeDrawer() { $("overlay").hidden = true; $("drawer").hidden = true; }
  function newConv() { store.newConversation(); renderAll(); closeDrawer(); $("question").focus(); }

  async function saveSettings() {
    const b = L.normalizeApiBase($("apiBase").value), err = $("settingsError");
    if (!b.ok) { err.textContent = b.error; err.hidden = false; return; }
    err.hidden = true; set(LS.base, b.value); set(LS.token, $("token").value.trim());
    await checkStatus(true);
  }

  function init() {
    store.load(); if (!store.current() && store.state.conversations.length) store.select(store.state.conversations[0].id);
    EXAMPLES.forEach(t => { const b = el("button", "chip", t); b.type = "button"; b.onclick = () => { $("question").value = t; $("question").focus(); autosize(); }; $("examples").append(b); });
    $("form").addEventListener("submit", e => { e.preventDefault(); send($("question").value); });
    $("question").addEventListener("input", autosize);
    $("clearDate").onclick = () => { $("factsDate").value = ""; };
    $("btnMenu").onclick = openDrawer; $("btnClose").onclick = closeDrawer; $("overlay").onclick = closeDrawer;
    $("btnNew").onclick = newConv; $("btnNew2").onclick = newConv; $("btnSave").onclick = saveSettings;
    $("btnWipe").onclick = () => { if (confirm("Effacer toutes les conversations de ce téléphone ?")) { store.clearAll(); renderAll(); renderConversations(); } };
    renderAll(); checkStatus(false);
    if ("serviceWorker" in navigator && (location.protocol === "https:" || location.hostname === "localhost"))
      navigator.serviceWorker.register("sw.js").catch(() => {});
  }
  document.addEventListener("DOMContentLoaded", init);
})();
