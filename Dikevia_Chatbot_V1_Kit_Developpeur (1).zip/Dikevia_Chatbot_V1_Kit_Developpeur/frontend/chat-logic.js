/* Logique pure du chat Dikevia (sans DOM) — testée avec Node : voir tests/frontend. */
(function (root, factory) {
  if (typeof module === "object" && module.exports) module.exports = factory();
  else root.DikeviaLogic = factory();
})(typeof self !== "undefined" ? self : this, function () {
  "use strict";
  const MAX_CONVERSATIONS = 30, MAX_MESSAGES = 60, MAX_EXCERPT = 800;

  function formatErrorDetail(detail) {
    if (!detail) return "Erreur inconnue.";
    if (typeof detail === "string") return detail;
    if (Array.isArray(detail)) return detail.map(d => (d && d.msg) || "Requête invalide").join(" ; ");
    return "Requête invalide.";
  }

  function statusInfo(status) {
    const map = {
      VERIFIE: { label: "Vérifié", tone: "ok" },
      PARTIELLEMENT_VERIFIE: { label: "Partiellement vérifié", tone: "warn" },
      NON_VERIFIE: { label: "Non vérifié", tone: "bad" },
    };
    return map[status] || { label: "Statut inconnu", tone: "bad" };
  }

  function sourceKind(source) {
    const map = {
      LEGIFRANCE_API: "Légifrance — article du CGFP (direct)",
      LEGIFRANCE_LODA: "Légifrance — texte réglementaire",
      LEGIFRANCE_CETAT_SEARCH: "Jurisprudence — résultat de recherche",
      LEGIFRANCE_CETAT_FULL_TEXT: "Jurisprudence — décision",
      CGFP_SNAPSHOT: "CGFP — index local (repère documentaire)",
    };
    return map[source && source.source_type] || "Source juridique";
  }

  function temporalInfo(ts) {
    const map = {
      IN_FORCE_ON_REQUESTED_DATE: { label: "Version à la date des faits", tone: "ok" },
      DECISION_AVAILABLE_BY_REQUESTED_DATE: { label: "Décision antérieure à la date", tone: "ok" },
      VERIFIED_APPLICABLE: { label: "Applicable (validé)", tone: "ok" },
      TEMPORAL_SCOPE_INCOMPLETE: { label: "Date non vérifiée", tone: "warn" },
      SNAPSHOT_ONLY_NOT_TEMPORALLY_VERIFIED: { label: "Version à la date non vérifiée", tone: "warn" },
    };
    return map[ts] || { label: "Portée temporelle non précisée", tone: "warn" };
  }

  function validateQuestion(q) {
    const t = (q || "").trim();
    if (t.length < 8) return { ok: false, error: "Décrivez votre question en au moins 8 caractères." };
    if (t.length > 5000) return { ok: false, error: "Question trop longue (5000 caractères maximum)." };
    return { ok: true, value: t };
  }

  function validateFactsDate(v) {
    if (!v) return { ok: true, value: null };
    if (!/^\d{4}-\d{2}-\d{2}$/.test(v)) return { ok: false, error: "Date invalide (format AAAA-MM-JJ)." };
    const d = new Date(v + "T00:00:00Z");
    if (isNaN(d) || d.toISOString().slice(0, 10) !== v) return { ok: false, error: "Cette date n'existe pas." };
    return { ok: true, value: v };
  }

  function normalizeApiBase(url) {
    const t = (url || "").trim().replace(/\/+$/, "");
    if (!t) return { ok: true, value: "" };
    let u;
    try { u = new URL(t); } catch (e) { return { ok: false, error: "Adresse invalide." }; }
    const local = ["localhost", "127.0.0.1"].includes(u.hostname);
    if (u.protocol !== "https:" && !(u.protocol === "http:" && local))
      return { ok: false, error: "L'adresse du serveur doit commencer par https://." };
    if (u.search || u.hash || u.username) return { ok: false, error: "Adresse invalide." };
    return { ok: true, value: u.origin + (u.pathname === "/" ? "" : u.pathname) };
  }

  function buildHistory(messages, max) {
    return (messages || [])
      .filter(m => m && (m.role === "user" || m.role === "assistant") && typeof m.content === "string")
      .slice(-(max || 12))
      .map(m => ({ role: m.role, content: m.content.slice(0, 5000) }));
  }

  function trimSources(sources) {
    return (sources || []).slice(0, 12).map(s => ({
      source_type: s.source_type, title: s.title, article: s.article, official_number: s.official_number,
      excerpt: (s.excerpt || "").slice(0, MAX_EXCERPT), temporal_status: s.temporal_status,
      source_status: s.source_status, page_start: s.page_start, page_end: s.page_end,
      official_url: s.official_url || s.source_url || null,
    }));
  }

  function friendlyNetworkError(err, httpStatus, detail) {
    if (httpStatus === 401) return "Accès refusé : code d'accès invalide ou manquant (menu ⚙).";
    if (httpStatus === 429) return "Trop de demandes. Patientez une minute puis réessayez.";
    if (httpStatus && httpStatus >= 500) return formatErrorDetail(detail) || "Erreur du serveur.";
    if (httpStatus) return formatErrorDetail(detail);
    return "Impossible de joindre le serveur Dikevia. Vérifiez votre connexion et l'adresse du serveur (menu ⚙). Si le serveur vient de se réveiller, réessayez dans 30 secondes.";
  }

  function titleFrom(q) {
    const t = (q || "").trim().replace(/\s+/g, " ");
    return t.length > 48 ? t.slice(0, 47) + "…" : t || "Nouvelle conversation";
  }

  /* Stockage local simple (appareil uniquement) — aucune base de données. */
  function createStore(storage, key) {
    let state = { current: null, conversations: [] };
    function load() {
      try { const raw = storage.getItem(key); if (raw) { const p = JSON.parse(raw); if (p && Array.isArray(p.conversations)) state = p; } }
      catch (e) { state = { current: null, conversations: [] }; }
      if (!state.conversations.some(c => c.id === state.current)) state.current = null;
      return state;
    }
    function save() {
      state.conversations = state.conversations.slice(0, MAX_CONVERSATIONS);
      try { storage.setItem(key, JSON.stringify(state)); } catch (e) { /* quota : on continue en mémoire */ }
    }
    function newConversation() {
      const existing = state.conversations.find(c => c.id === state.current && c.messages.length === 0);
      if (existing) return existing;
      const c = { id: "c" + Date.now().toString(36) + Math.random().toString(36).slice(2, 6), title: "Nouvelle conversation", updatedAt: Date.now(), messages: [] };
      state.conversations.unshift(c); state.current = c.id; save(); return c;
    }
    function current() { return state.conversations.find(c => c.id === state.current) || null; }
    function select(id) { if (state.conversations.some(c => c.id === id)) { state.current = id; save(); } return current(); }
    function addMessage(msg) {
      const c = current() || newConversation();
      if (msg.role === "user" && c.messages.length === 0) c.title = titleFrom(msg.content);
      c.messages.push(msg); c.messages = c.messages.slice(-MAX_MESSAGES); c.updatedAt = Date.now();
      state.conversations.sort((a, b) => b.updatedAt - a.updatedAt); save(); return c;
    }
    function remove(id) {
      state.conversations = state.conversations.filter(c => c.id !== id);
      if (state.current === id) state.current = state.conversations.length ? state.conversations[0].id : null;
      save();
    }
    function clearAll() { state = { current: null, conversations: [] }; save(); }
    return { load, save, newConversation, current, select, addMessage, remove, clearAll, get state() { return state; } };
  }

  return { formatErrorDetail, statusInfo, sourceKind, temporalInfo, validateQuestion, validateFactsDate,
    normalizeApiBase, buildHistory, trimSources, friendlyNetworkError, titleFrom, createStore };
});
