/* Configuration de l'application. Pour l'APK, ce fichier est généré à la compilation
   (voir .github/workflows/android-apk.yml). Aucune clé secrète ici : jamais. */
window.DIKEVIA_CONFIG = { apiBase: "" };
