# Connecteur Légifrance / PISTE (`backend/app/legifrance.py`)

## Variables (serveur uniquement)
`LEGIFRANCE_ENVIRONMENT` (sandbox | production), `LEGIFRANCE_CLIENT_ID`, `LEGIFRANCE_CLIENT_SECRET`, `LEGIFRANCE_SCOPE` (openid), `LEGIFRANCE_TIMEOUT_SECONDS`, `LEGIFRANCE_CODE_NAME`, `LEGIFRANCE_CETAT_FULLTEXT_ENABLED`.
Obtention : compte PISTE, application avec abonnement à l'API Légifrance, identifiants OAuth2 « client credentials ».

## Flux
1. Jeton : `POST …/oauth/token` (grant `client_credentials`), mis en cache avec marge de 60 s.
2. Articles du code : `POST /search` (fond `CODE_DATE`, filtre `NOM_CODE` + `DATE_VERSION` = date des faits) puis `POST /consult/getArticle`. Un article n'est retenu que si l'identifiant LEGIARTI retourné correspond **et** que son numéro propre est prouvé (champ `num`, sinon début du texte) lorsqu'un article précis est demandé.
3. Textes réglementaires : `POST /search` (fond `LODA_DATE`) puis `POST /consult/legiPart` à la date des faits ; texte intégral exigé.
4. Jurisprudence : fonds CETAT, résultats de recherche (le texte intégral n'est pas présenté comme tel).
5. Toute panne (`LegifranceUnavailable`) produit un message explicite dans « Points à vérifier » ; aucune règle n'est jamais déduite d'une recherche vide.

## État
Modifié et testé sur doublures : calcul du numéro d'article. **Jamais exécuté contre PISTE.** Premier test réel à faire : variables PISTE sandbox → démarrer → ☰ → pastille Légifrance verte → question « article L121-1 » avec une date des faits.
