# Journal des modifications

## Connecteur PISTE — numéro d'article
- Nouveau module `backend/app/article_ref.py` (sans dépendance).
- `legifrance.py` : le numéro d'un article retourné est lu dans le champ `num` de l'API, ou à défaut au tout début du texte. Un renvoi vers un autre article dans le corps du texte n'est plus pris pour son numéro.
- Une référence demandée exige désormais un tiret (L121-1) : « d 5 jours » n'est plus pris pour un article.
- Si le numéro propre n'est pas prouvable alors qu'un article précis est demandé, l'article est écarté (échec fermé).
- Tests : `backend/tests/test_article_ref_and_piste_validation.py` (7 tests, exécutés avec doublures httpx/config, sans réseau).

## Non vérifié
Aucun appel réel à PISTE ; suite pytest complète non exécutée (dépendances absentes de l'environnement d'édition).

## Démonstrateur mobile
- `cgfp.py` : références d'articles reconnues via `article_ref.py` (L. 121-1, L4) ; une référence inexistante ne ramène plus de résultats sans rapport et est signalée (`unknown_refs`). Régression « L4 » corrigée avant livraison.
- `orchestrator.py` : messages explicites si une référence est absente de l'index, si l'IA n'est pas configurée ou indisponible.
- `dev_main.py` : `/api/v1/status`, gestion d'erreurs en français, CORS, code d'accès, limite de débit (`guard.py`).
- `frontend/` : refonte mobile (accueil, exemples, sources, points à vérifier, conversations locales, paramètres), PWA, icônes.
- Ajouts : `Dockerfile`, `render.yaml`, `package.json`, `capacitor.config.json`, `scripts/prepare-www.js`, `.github/workflows/android-apk.yml`, `assets/`.
