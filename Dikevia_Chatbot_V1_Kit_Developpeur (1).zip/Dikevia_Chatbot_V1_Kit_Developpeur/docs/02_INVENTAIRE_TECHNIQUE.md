# Inventaire technique — réutilisation du projet existant

| Élément existant | Décision V1 | Rôle |
|---|---|---|
| `orchestrator.py` | Conservé | Chaîne question/recherche/analyse/réponse |
| `cgfp.py` | Conservé | Recherche locale dans l'index article/page du CGFP |
| `corpus_national/index/*` | Conservé | Index JSON documentaire |
| `corpus_national/legislation/*` | Conservé | PDF source + métadonnées de provenance |
| `legifrance.py` | Conservé | Authentification PISTE et consultation des textes |
| `jurisprudence.py` | Conservé | Repérage CETAT, portée limitée explicitée |
| `legal_validation.py` | Conservé | Date stricte et validation de cohérence du snapshot |
| `legal_assurance.py` | Conservé | Classement prudent des sources |
| `ai_provider.py` | Conservé | Adaptateur IA et prompt Dikevia |
| `schemas.py` | Réutilisé | Contrats de requête/réponse |
| `main.py` d'origine | Exclu | Démarrage et routes métier fortement couplés à la base |
| `db.py`, `dependencies.py`, migrations | Exclus | PostgreSQL / multi-tenant différés |
| `frontend/index.html` d'origine | Remplacé dans ce kit | Contient les écrans annexes ; remplacé par un chat seul |
| `billing.py`, `dossiers.py`, documents, invitations | Exclus | Hors périmètre du chatbot V1 |

Le code du dépôt principal n'est pas supprimé ni réécrit par ce kit. Le point d'entrée local est un adaptateur de développement séparé.
