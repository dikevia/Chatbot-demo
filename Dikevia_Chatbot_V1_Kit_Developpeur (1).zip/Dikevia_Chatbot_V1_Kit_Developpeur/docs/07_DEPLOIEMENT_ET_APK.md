# Déploiement et installation depuis un téléphone Android (sans PC)

> **Aucune des étapes ci-dessous n'a été exécutée de bout en bout.** Le code et les workflows sont écrits, mais ni le déploiement, ni la compilation de l'APK, ni l'installation sur un appareil n'ont été testés. Faites remonter toute erreur : les corrections se feront sur les journaux réels.

## Prérequis (comptes gratuits)
1. Un compte **GitHub** (github.com, depuis Chrome Android).
2. Un compte **Render** (render.com) — ou tout hébergeur Docker.
3. Optionnel pour l'analyse rédigée : identifiants **PISTE** (sandbox) et clé d'un **fournisseur d'IA** compatible OpenAI. Sans eux, l'app fonctionne en mode « sources seules ».

## Étape 0 — Mettre le code sur GitHub depuis un téléphone (méthode « un seul zip »)
GitHub n'accepte pas un dossier depuis un téléphone, mais accepte **un fichier .zip**. Le build cloud le décompresse.
1. Chrome → github.com → créer un dépôt **privé** (ex. `dikevia`).
2. *Add file → Upload files* : choisir `Dikevia_Chatbot_V1_Kit_Developpeur.zip` (un seul fichier) → *Commit changes*.
3. *Add file → Create new file* : nom `Dockerfile` → coller le contenu de `PHONE_BOOTSTRAP/Dockerfile.racine` → *Commit*.
4. *Add file → Create new file* : nom `.github/workflows/android-apk.yml` (les `/` créent les dossiers) → coller `PHONE_BOOTSTRAP/android-apk.racine.yml` → *Commit*.
Ne mettez jamais de clé ni de `.env` dans le dépôt. Un seul .zip à la racine (supprimez les anciennes versions).

## Étape 1 — Déployer le serveur (Render)
1. Render → *New* → **Web Service** → choisir le dépôt → runtime **Docker** (il utilise le `Dockerfile` racine) → plan Free → *Health Check Path* `/health`. (Avec un dépôt complet, *Blueprint* + `render.yaml` fonctionne aussi.)
2. Dans *Environment*, ajouter : `DIKEVIA_DEMO_TOKEN` (un code de votre choix, 20 caractères ou plus), `APP_ENV=production`, puis les secrets que vous avez (laisser les autres) : `LEGIFRANCE_CLIENT_ID`, `LEGIFRANCE_CLIENT_SECRET`, `AI_API_BASE_URL`, `AI_API_KEY`, `AI_MODEL`.
3. `DIKEVIA_DEMO_TOKEN` est le « code d'accès » à saisir dans l'application.
4. Noter l'adresse du service, ex. `https://dikevia-backend.onrender.com`. Ouvrir `…/health` : doit afficher `"status":"ok"`.
Le plan gratuit s'endort après inactivité : la 1re requête peut prendre ~30-60 s.

## Étape 2a — Installer comme application, sans APK (PWA)
Ouvrir l'adresse du serveur dans **Chrome Android** → menu ⋮ → **Installer l'application** (ou *Ajouter à l'écran d'accueil*). L'icône Dikevia apparaît, l'app s'ouvre en plein écran. Menu ☰ de l'app → saisir le code d'accès.

## Étape 2b — Générer l'APK (compilation dans le cloud)
1. GitHub → dépôt → *Settings* → *Secrets and variables* → *Actions* → onglet **Variables** → *New repository variable* : `DIKEVIA_API_BASE` = l'adresse HTTPS du serveur (sans secret).
2. Onglet **Actions** → « Générer l'APK Android Dikevia » → **Run workflow**. Durée attendue : 5 à 10 minutes.
3. Une fois vert : dépôt → **Releases** → télécharger `Dikevia-demo.apk` avec Chrome sur le téléphone.
4. Ouvrir le fichier téléchargé ; Android demande d'autoriser l'installation depuis ce navigateur (« sources inconnues ») ; confirmer.
5. Ouvrir Dikevia → ☰ → saisir le code d'accès → *Enregistrer et tester* : les pastilles doivent être vertes.

L'APK produit est un APK **debug** (signé avec la clé de débogage) : adapté à une démo, pas à une publication sur le Play Store.

## Dépannage rapide
- « Serveur injoignable » : serveur endormi (réessayer après 60 s) ou adresse erronée (☰).
- « Code d'accès refusé » : recopier `DIKEVIA_DEMO_TOKEN` depuis Render.
- Pastille Légifrance rouge : identifiants PISTE absents ou invalides (voir `09_CONNECTEUR_PISTE.md`).
- Le workflow échoue : ouvrir le journal de l'étape en rouge ; la cause la plus probable est une version d'outil (Capacitor/Java) à ajuster.
