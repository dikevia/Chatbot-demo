# Plan de recette — chatbot V1

## A. Compréhension de la question
- Question courte et claire.
- Question longue avec plusieurs faits.
- Question avec fautes et langage courant.
- Question ambiguë : le système doit demander une précision utile.
- Question sans date : pas de conclusion contextualisée.
- Question avec date invalide : rejet clair.

## B. Recherche et sources
- Article CGFP cité explicitement par l'utilisateur.
- Recherche thématique sans numéro d'article.
- Question nécessitant un décret d'application.
- Question nécessitant un texte spécial hors CGFP.
- Texte modifié entre la date des faits et aujourd'hui.
- Texte abrogé ou remplacé.
- Source officielle inaccessible / quota PISTE dépassé.
- Aucun résultat : ne pas conclure qu'aucune règle n'existe.

## C. Contrôle des réponses
- Référence présente dans les sources.
- Référence inventée par le modèle : réponse écartée.
- Numéro de décret absent des sources : réponse écartée.
- Snapshot CGFP seul : aucune conclusion temporelle.
- Métadonnées seules : aucune citation présentée comme texte intégral.
- Sources contradictoires : divergence explicitée.
- Réponse avec faits, règle, application, réserves et actions.

## D. Mesure de qualité
Constituer un jeu de questions juridiques revu par un professionnel compétent. Pour chaque cas, enregistrer : formulation, date des faits, statut (titulaire/contractuel si pertinent), faits déterminants, sources attendues, version temporelle attendue, réponse de référence et critères d'échec. Mesurer séparément : précision des sources, exactitude temporelle, couverture des règles, taux d'abstention justifiée et taux de références non fondées. Une bonne réponse n'est pas seulement une réponse plausible.

## E. Critère de lancement
Aucun lancement commercial avant : tests de non-régression réussis, contrôle PISTE réel, validation d'un échantillon représentatif de réponses, test de charge et revue sécurité/authentification du véritable environnement de production.
