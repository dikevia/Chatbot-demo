# État réel du projet (aucun pourcentage : seulement des faits)

Légende : ✅ exécuté et réussi · 🟡 codé, non exécuté · 🔑 nécessite des identifiants externes · ⬜ à développer

## Ce qui est construit
Moteur juridique (orchestrateur, index CGFP 4 242 articles, connecteur PISTE, jurisprudence CETAT, contrôle des citations, abstention), interface mobile (accueil, exemples, chat, sources, points à vérifier, conversations locales, paramètres serveur, états d'erreur), PWA (manifest, service worker, icônes), garde d'accès + limite de débit + CORS, Dockerfile et Blueprint Render, projet Capacitor et workflow de génération d'APK.

## Fonctionnalités testées et validées (exécutées dans l'environnement de rédaction)
- ✅ Intégrité du corpus CGFP (hash PDF, index, 4 242 articles) — `scripts/check_cgfp_corpus.py`.
- ✅ Recherche CGFP sur 9 thèmes (congés, maladie, temps de travail, heures sup., primes, avancement, discipline, droit syndical, obligations de l'employeur) : articles réels, pages, extraits — *mécanique seulement ; la **justesse juridique** des résultats n'a pas été évaluée*.
- ✅ Référence inexistante : aucun résultat inventé, signalée (`unknown_refs`) ; articles sans tiret (L4) ; faux positifs (« d 5 jours »).
- ✅ Validation du numéro d'article PISTE (sur de fausses réponses API, sans réseau).
- ✅ Garde d'accès : code, limite de débit, origine IP via proxy.
- ✅ Logique de l'application (10 tests Node) : erreurs lisibles, validation question/date/adresse HTTPS, historique, conversations multiples, stockage corrompu.
- ✅ `prepare-www.js` : écrit l'adresse du serveur, refuse une adresse non HTTPS ou avec identifiants.
- ✅ Syntaxe JS, manifest JSON, YAML, identifiants DOM de l'interface.

## Codé mais NON testé
- 🟡 Démarrage du serveur FastAPI (`dev_main.py`) : fastapi indisponible ici.
- 🟡 `backend/tests/test_mobile_api.py` (TestClient) et le reste de la suite pytest (dont `test_cgfp_search.py`, qui dépend de pydantic).
- 🟡 Rendu et usage de l'interface dans un navigateur / WebView : jamais ouverte sur un écran.
- 🟡 PWA : installation et service worker.
- 🟡 Dockerfile, `render.yaml`, workflow GitHub Actions, versions Capacitor 6.2.0 / Assets 3.0.5.
- 🟡 Nouveaux messages « IA non configurée / indisponible » et « référence absente de l'index » de l'orchestrateur.

## Nécessite des identifiants externes
- 🔑 Authentification OAuth2 PISTE, recherche et consultation Légifrance, version à la date des faits, jurisprudence : jamais exécutées en réel.
- 🔑 Réponses rédigées par l'IA et rejet des références non fondées en conditions réelles.

## Non fait / à développer
- ⬜ **APK : non généré, non installé, non testé sur un appareil Android.** Le projet n'est donc **pas terminé** au sens de la consigne.
- ⬜ Évaluation de la qualité juridique par un professionnel (voir `04_PLAN_DE_RECETTE.md`, section D).
- ⬜ Relecture complète du connecteur PISTE (renouvellement du jeton, quotas, erreurs) : seule la validation du numéro d'article a été revue.
- ⬜ Test de charge, revue de sécurité, APK signé « release », publication Play Store.
- ⬜ Stopwords : « et », « le »… peuvent encore ressortir comme mots-clés dans certaines requêtes (observé sur « L. 121-1 et R. 9-9 »).
