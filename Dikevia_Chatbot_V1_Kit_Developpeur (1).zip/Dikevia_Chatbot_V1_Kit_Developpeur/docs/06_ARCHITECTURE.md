# Architecture et choix technique

## Comparaison des trois options (contrainte : aucun PC, maintenance simple, réutilisable)
| Option | Avantages | Inconvénients | Verdict |
|---|---|---|---|
| **PWA seule** | Aucun APK, installation directe depuis Chrome, mises à jour instantanées | Pas de « vrai » APK à montrer, pas de présence Play Store | Solution de repli, **fournie** |
| **Capacitor** (retenu pour l'APK) | Même code web que la PWA et que la future appli commerciale ; APK compilable dans le cloud ; accès futur aux fonctions natives (notifications, biométrie) | Une chaîne de build Android à maintenir | **Retenu** |
| **Android natif (Kotlin)** | Contrôle total | Deuxième base de code à maintenir, aucune réutilisation web, plus long | Écarté |

Décision : **une seule application web mobile**, servie telle quelle (PWA) et emballée dans un APK par Capacitor. Le futur produit commercial réutilise le même front.

## Schéma
```
Téléphone (APK Capacitor ou PWA)         Serveur (Docker, HTTPS)
 frontend/ : UI, conversations locales ──HTTPS──▶ backend/dev_main.py
 aucun secret                                    ├─ garde : code d'accès + limite par IP + CORS
                                                 ├─ orchestrator.py (moteur juridique)
                                                 │   ├─ cgfp.py ........ index local (corpus_national/)
                                                 │   ├─ legifrance.py ... PISTE (secrets côté serveur)
                                                 │   ├─ jurisprudence.py  CETAT
                                                 │   └─ ai_provider.py .. IA + contrôle des citations
                                                 └─ aucune base de données
```

## Sécurité (ce qui est fait / ce qui reste)
- Clés PISTE et IA : uniquement dans les variables d'environnement du serveur ; l'application n'en contient aucune (`scripts/prepare-www.js` n'écrit que l'adresse du serveur).
- Transport : HTTPS imposé côté application (l'adresse `http://` est refusée sauf localhost) et côté Android (cleartext désactivé).
- Serveur exposé : code d'accès partagé (`DIKEVIA_DEMO_TOKEN`, en-tête `X-Demo-Token`), limite de débit par IP, CORS restreint.
- **Limite connue** : le code d'accès est saisi dans l'appli et stocké sur le téléphone ; ce n'est pas un système de comptes. Suffisant pour une démo à des amis, pas pour un produit public.

## Données sur l'appareil
Conversations dans le `localStorage` du téléphone (30 conversations max, 60 messages chacune). Effaçables depuis le menu. Rien n'est enregistré côté serveur.
