# Moteur juridique, PostgreSQL reporté, feuille de route

## Règles du moteur (`orchestrator.py`)
- Sans date des faits : repérage documentaire uniquement, aucune analyse contextualisée.
- Le snapshot CGFP seul ne produit jamais de conclusion (il n'établit pas la version applicable à une date).
- L'IA ne reçoit que des sources contrôlées ; toute référence d'article/décret absente de ces sources fait **écarter** la réponse (`answer_references_are_grounded`).
- Métadonnées de jurisprudence ≠ décision intégrale. Sans source exploitable : abstention.
- Statuts : `VERIFIE` n'est jamais attribué automatiquement par ce kit ; au mieux `PARTIELLEMENT_VERIFIE`.

## PostgreSQL : reporté, non supprimé
Le démonstrateur appelle le moteur avec `conn=None` : aucune connexion, aucune migration, aucun blocage au démarrage. Le code dépendant d'une base subsiste, **inactif**, pour les futurs développeurs :
- `backend/app/legal_corpus.py` (corpus permanent, requêtes SQL), `backend/app/local_corpus.py` (documents propres à une collectivité) ;
- branches `conn is not None` et `employer != "NATIONAL"` de `orchestrator.py` ;
- modèles de comptes/organisations/documents dans `schemas.py` (non utilisés).
Les migrations, `db.py`, l'authentification et la facturation du dépôt principal sont volontairement hors de ce kit.

## Feuille de route vers la version commerciale
1. Recette réelle : PISTE sandbox puis production, APK sur appareils réels, jeu de questions validé par un juriste.
2. Remplacer le code d'accès partagé par de vraies identités (OIDC) et des quotas par utilisateur.
3. Réactiver PostgreSQL : historique persistant, corpus permanent, documents locaux, multi-organisations.
4. Qualité de recherche : synonymes/lemmatisation, stopwords, recherche sémantique, textes spéciaux FPT.
5. Mobile : APK « release » signé, notifications, authentification biométrique, publication Play Store.
6. Industrialisation : CI avec tests complets, observabilité, test de charge, revue sécurité.
