# Périmètre produit — Dikevia Chatbot V1

## Promesse produit
Un agent ou représentant décrit une situation en langage courant. Dikevia identifie les éléments juridiques utiles, recherche le CGFP et les sources officielles complémentaires, contrôle leur portée temporelle, puis répond avec des références vérifiables ou s'abstient.

## Chaîne fonctionnelle
1. Comprendre la question et repérer les faits manquants.
2. Demander la date des faits lorsque nécessaire.
3. Rechercher dans l'index documentaire du CGFP (référence nationale de départ).
4. Interroger Légifrance/PISTE pour obtenir le texte officiel et la version applicable à la date demandée.
5. Rechercher les textes réglementaires complémentaires.
6. Repérer la jurisprudence pertinente, sans confondre résultat de recherche et décision intégrale.
7. Transmettre au modèle uniquement les sources admises par les contrôles du backend.
8. Contrôler les références générées ; écarter une réponse qui cite un article ou numéro absent des sources fournies.
9. Afficher les sources, le statut de vérification et les limites.

## Hors périmètre V1
Génération de courriers, recours automatiques, analyse de pièces téléversées, dossiers, espaces locaux, administration, gestion des comptes, facturation, persistance de l'historique et multi-tenant.

## Règle de qualité
Ne jamais annoncer une fiabilité de 100 %. L'objectif est une fiabilité maximale mesurée, une traçabilité des sources et l'absence de fausse certitude. Le statut `VERIFIE` ne peut être utilisé que si les contrôles prévus sont réellement exécutés ; les tests doivent aussi vérifier les cas d'abstention.
