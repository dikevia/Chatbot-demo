# Règles de fiabilité juridique

- Le CGFP est le socle de recherche et de compréhension de la fonction publique, dont la FPT. Il ne suffit pas à lui seul pour toutes les questions.
- Le PDF fourni est une photographie documentaire datée ; il ne prouve pas seul la version applicable à une date passée.
- Les textes officiels Légifrance/PISTE consultés à la date des faits sont nécessaires pour établir la rédaction et l'applicabilité temporelle.
- Les décrets, arrêtés, textes spéciaux et jurisprudences sont ajoutés selon la question.
- Un résultat CETAT ou une métadonnée ne vaut pas texte intégral de décision.
- Aucune citation juridique ne doit être créée par le modèle : les références exposées doivent provenir des sources récupérées.
- Les faits, hypothèses, éléments manquants et conclusions doivent être distingués.
- Une date absente ou invalide bloque l'analyse juridique contextualisée.
- Une source absente, inaccessible ou contradictoire déclenche une limite explicite ou une abstention.
- La recherche infructueuse dans le seul snapshot ne prouve jamais l'absence de règle.

## Limite importante du kit
La recherche de l'index CGFP est une recherche documentaire locale. Elle n'est pas, en soi, une validation officielle de l'article. Le parcours PISTE doit être testé en sandbox avec des identifiants réels, puis validé avant d'être activé en production.
